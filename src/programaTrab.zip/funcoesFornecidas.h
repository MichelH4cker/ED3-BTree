#ifndef __FUNCOESFORNECIDAS_H__
#define __FUNCOESFORNECIDAS_H__

#include "main.h"

void readline(char *string);

void binarioNaTela(char *nomeArquivoBinario);

void scan_quote_string(char *str);

#endif