#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#include "main.h"

register_bin readInput(register_bin register_bin);

void insertInto(char *file_input_data, char *file_input_index, int n);

#endif