#ifndef __MAIN_H__
#define __MAIN_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#include "data_file.h"
#include "b-tree.h"
#include "index_file.h"
#include "funcoesFornecidas.h"
#include "commands.h"

#define DEBUG -1

void menu();

#endif